package com.secondhandmarket.tools;

public interface Types {
      static String  INT  = "i",STR  = "s",FLT = "f";
      
}
