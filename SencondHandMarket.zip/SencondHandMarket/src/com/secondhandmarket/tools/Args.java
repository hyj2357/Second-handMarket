package com.secondhandmarket.tools;

public class Args {
     private String[] args;
     private Object[] argsData;
	
     public String[] getArgs() {
		return args;
	 }
	
     public void setArgs(String[] args) {
		this.args = args;
	 }
	
     public Object[] getArgsData() {
		return argsData;
	 }
	
     public void setArgsData(Object[] argsData) {
		this.argsData = argsData;
	 }
     
     
}
